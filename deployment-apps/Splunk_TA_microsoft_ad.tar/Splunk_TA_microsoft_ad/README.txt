Splunk Add-on for Microsoft Active Directory version 1.0.0
Copyright (C) 2005-2016 Splunk Inc. All Rights Reserved.

For documentation, see: http://docs.splunk.com/Documentation/DCDNSAddOn/latest