Splunk Add-on for Microsoft Hyper-V version 3.1.0
Copyright (C) 2019 Splunk Inc. All Rights Reserved.

For documentation, see: http://docs.splunk.com/Documentation/AddOns/latest/MSHyperV
